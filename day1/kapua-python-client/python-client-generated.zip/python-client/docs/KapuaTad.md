# KapuaTad

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**KapuaTscalar**](KapuaTscalar.md) |  | [optional] 
**option** | [**list[KapuaToption]**](KapuaToption.md) |  | [optional] 
**default** | **str** |  | [optional] 
**other_attributes** | **dict(str, str)** |  | [optional] 
**cardinality** | **int** |  | [optional] 
**any** | **list[object]** |  | [optional] 
**required** | **bool** |  | [optional] 
**min** | **str** |  | [optional] 
**max** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


