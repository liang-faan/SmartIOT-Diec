# KapuaDataChannel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**semantic_parts** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


