# SortField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sort_direction** | **str** |  | [optional] 
**field** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


