# KapuaToption

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**other_attributes** | **dict(str, str)** |  | [optional] 
**any** | **list[object]** |  | [optional] 
**label** | **str** |  | [optional] 
**value** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


