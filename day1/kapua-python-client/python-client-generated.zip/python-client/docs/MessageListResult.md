# MessageListResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**list[DatastoreMessage]**](DatastoreMessage.md) |  | [optional] 
**limit_exceeded** | **bool** |  | [optional] 
**first_item** | [**DatastoreMessage**](DatastoreMessage.md) |  | [optional] 
**next_key** | **object** |  | [optional] 
**total_count** | **int** |  | [optional] 
**empty** | **bool** |  | [optional] 
**size** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


