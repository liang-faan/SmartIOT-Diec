# KapuaPosition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**precision** | **float** |  | [optional] 
**timestamp** | **datetime** |  | [optional] 
**heading** | **float** |  | [optional] 
**speed** | **float** |  | [optional] 
**satellites** | **int** |  | [optional] 
**longitude** | **float** |  | [optional] 
**status** | **int** |  | [optional] 
**latitude** | **float** |  | [optional] 
**altitude** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


