# GenericResponsePayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exception_message** | **str** |  | [optional] 
**exception_stack** | **str** |  | [optional] 
**body** | **str** |  | [optional] 
**metrics** | **dict(str, object)** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


