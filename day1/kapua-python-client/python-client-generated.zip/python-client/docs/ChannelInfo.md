# ChannelInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scope_id** | **str** |  | [optional] 
**client_id** | **str** |  | [optional] 
**id** | [**StorableId**](StorableId.md) |  | [optional] 
**last_message_on** | **datetime** |  | [optional] 
**first_message_id** | [**StorableId**](StorableId.md) |  | [optional] 
**first_message_on** | **datetime** |  | [optional] 
**last_message_id** | [**StorableId**](StorableId.md) |  | [optional] 
**name** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


