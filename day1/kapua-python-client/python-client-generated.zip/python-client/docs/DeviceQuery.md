# DeviceQuery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limit** | **int** |  | [optional] 
**scope_id** | **str** |  | [optional] 
**fetch_attributes** | **list[str]** |  | [optional] 
**predicate** | [**QueryPredicate**](QueryPredicate.md) |  | [optional] 
**sort_criteria** | [**KapuaSortCriteria**](KapuaSortCriteria.md) |  | [optional] 
**offset** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


