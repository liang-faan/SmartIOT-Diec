# AccessRole

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role_id** | **str** |  | [optional] 
**access_info_id** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**scope_id** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**created_by** | **str** |  | [optional] 
**created_on** | **datetime** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


