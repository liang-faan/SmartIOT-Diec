# CredentialCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expiration_date** | **datetime** |  | [optional] 
**user_id** | **str** |  | [optional] 
**credential_type** | **str** |  | [optional] 
**credential_status** | **str** |  | [optional] 
**credential_key** | **str** |  | [optional] 
**scope_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


