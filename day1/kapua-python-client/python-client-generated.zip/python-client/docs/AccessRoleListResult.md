# AccessRoleListResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**list[AccessRole]**](AccessRole.md) |  | [optional] 
**limit_exceeded** | **bool** |  | [optional] 
**first_item** | [**AccessRole**](AccessRole.md) |  | [optional] 
**empty** | **bool** |  | [optional] 
**size** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


