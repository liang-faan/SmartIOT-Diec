# Domain

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**domain** | [**Domain**](Domain.md) |  | [optional] 
**groupable** | **bool** |  | [optional] 
**actions** | **list[str]** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**scope_id** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**created_by** | **str** |  | [optional] 
**created_on** | **datetime** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


