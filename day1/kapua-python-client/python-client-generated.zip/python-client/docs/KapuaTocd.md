# KapuaTocd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**icon** | [**list[KapuaTicon]**](KapuaTicon.md) |  | [optional] 
**other_attributes** | **dict(str, str)** |  | [optional] 
**any** | **list[object]** |  | [optional] 
**description** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**ad** | [**list[KapuaTad]**](KapuaTad.md) |  | 
**name** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


