# DatastoreMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timestamp** | **datetime** |  | [optional] 
**position** | [**KapuaPosition**](KapuaPosition.md) |  | [optional] 
**scope_id** | **str** |  | [optional] 
**device_id** | [**KapuaId**](KapuaId.md) |  | [optional] 
**client_id** | **str** |  | [optional] 
**channel** | [**KapuaDataChannel**](KapuaDataChannel.md) |  | [optional] 
**id** | **str** |  | [optional] 
**payload** | [**KapuaPayload**](KapuaPayload.md) |  | [optional] 
**received_on** | **datetime** |  | [optional] 
**sent_on** | **datetime** |  | [optional] 
**captured_on** | **datetime** |  | [optional] 
**datastore_id** | [**StorableId**](StorableId.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


