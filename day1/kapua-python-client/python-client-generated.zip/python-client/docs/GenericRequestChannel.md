# GenericRequestChannel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resources** | **list[str]** |  | [optional] 
**method** | **str** |  | [optional] 
**version** | [**KapuaAppProperties**](KapuaAppProperties.md) |  | [optional] 
**app_name** | [**KapuaAppProperties**](KapuaAppProperties.md) |  | [optional] 
**semantic_parts** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


