# JsonKapuaPayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metrics** | [**list[XmlAdaptedMetric]**](XmlAdaptedMetric.md) |  | [optional] 
**body** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


