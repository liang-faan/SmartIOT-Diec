# AccessInfoCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**permissions** | [**list[Permission]**](Permission.md) |  | [optional] 
**user_id** | **str** |  | [optional] 
**role_ids** | **str** |  | [optional] 
**scope_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


