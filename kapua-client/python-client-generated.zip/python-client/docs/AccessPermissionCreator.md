# AccessPermissionCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_info_id** | **str** |  | [optional] 
**permission** | [**Permission**](Permission.md) |  | [optional] 
**scope_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


