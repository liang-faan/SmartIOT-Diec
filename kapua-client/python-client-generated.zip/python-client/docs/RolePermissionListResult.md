# RolePermissionListResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**list[RolePermission]**](RolePermission.md) |  | [optional] 
**first_item** | [**RolePermission**](RolePermission.md) |  | [optional] 
**limit_exceeded** | **bool** |  | [optional] 
**empty** | **bool** |  | [optional] 
**size** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


