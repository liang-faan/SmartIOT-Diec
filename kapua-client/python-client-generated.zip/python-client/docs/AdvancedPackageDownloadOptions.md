# AdvancedPackageDownloadOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**block_size** | **int** |  | [optional] 
**notify_block_size** | **int** |  | [optional] 
**install_verifier_uri** | **str** |  | [optional] 
**block_delay** | **int** |  | [optional] 
**block_timeout** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


