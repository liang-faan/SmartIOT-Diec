# AccountCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expiration_date** | **datetime** |  | [optional] 
**organization_person_name** | **str** |  | [optional] 
**organization_email** | **str** |  | [optional] 
**organization_phone_number** | **str** |  | [optional] 
**organization_address_line1** | **str** |  | [optional] 
**organization_address_line2** | **str** |  | [optional] 
**organization_city** | **str** |  | [optional] 
**organization_zip_post_code** | **str** |  | [optional] 
**organization_state_province_county** | **str** |  | [optional] 
**organization_name** | **str** |  | [optional] 
**organization_country** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**entity_attributes** | **dict(str, str)** |  | [optional] 
**scope_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


