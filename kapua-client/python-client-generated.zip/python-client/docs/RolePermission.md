# RolePermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role_id** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**permission** | [**Permission**](Permission.md) |  | [optional] 
**scope_id** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**created_on** | **datetime** |  | [optional] 
**created_by** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


