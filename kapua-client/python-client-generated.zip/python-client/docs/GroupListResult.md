# GroupListResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**list[Group]**](Group.md) |  | [optional] 
**first_item** | [**Group**](Group.md) |  | [optional] 
**limit_exceeded** | **bool** |  | [optional] 
**empty** | **bool** |  | [optional] 
**size** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


