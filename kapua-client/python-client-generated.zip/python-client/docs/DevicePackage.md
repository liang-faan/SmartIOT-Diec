# DevicePackage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **str** |  | [optional] 
**bundle_infos** | [**DevicePackageBundleInfos**](DevicePackageBundleInfos.md) |  | [optional] 
**install_date** | **datetime** |  | [optional] 
**name** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


