# Permission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**domain** | **str** |  | [optional] 
**action** | **str** |  | [optional] 
**group_id** | **str** |  | [optional] 
**target_scope_id** | **str** |  | [optional] 
**forwardable** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


