# KapuaTocd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**icon** | [**list[KapuaTicon]**](KapuaTicon.md) |  | [optional] 
**description** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**ad** | [**list[KapuaTad]**](KapuaTad.md) |  | 
**other_attributes** | **dict(str, str)** |  | [optional] 
**any** | **list[object]** |  | [optional] 
**name** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


