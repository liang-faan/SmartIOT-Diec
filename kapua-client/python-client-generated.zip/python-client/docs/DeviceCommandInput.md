# DeviceCommandInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**environment** | **list[str]** |  | [optional] 
**password** | **str** |  | [optional] 
**timeout** | **int** |  | [optional] 
**working_dir** | **str** |  | [optional] 
**arguments** | **list[str]** |  | [optional] 
**body** | **list[str]** |  | [optional] 
**command** | **str** |  | [optional] 
**run_asynch** | **bool** |  | [optional] 
**stdin** | **str** |  | [optional] 
**scope_id** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**created_on** | **datetime** |  | [optional] 
**created_by** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


