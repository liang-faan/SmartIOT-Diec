# LoginInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_token** | [**AccessToken**](AccessToken.md) |  | [optional] 
**role_permission** | [**list[RolePermission]**](RolePermission.md) |  | [optional] 
**access_permission** | [**list[AccessPermission]**](AccessPermission.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


