# KapuaPosition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timestamp** | **datetime** |  | [optional] 
**precision** | **float** |  | [optional] 
**status** | **int** |  | [optional] 
**longitude** | **float** |  | [optional] 
**latitude** | **float** |  | [optional] 
**altitude** | **float** |  | [optional] 
**heading** | **float** |  | [optional] 
**speed** | **float** |  | [optional] 
**satellites** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


